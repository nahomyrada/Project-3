
package Modelo;


public class Tratamiento {
    private String nombre;
    private String descripcion;
    private float costo;
    private String duracion;
    private String[] materiales; //creo que materiales e instrumentos no va
    private String[] intrumentos;

    public Tratamiento() {
    }

    public Tratamiento(String nombre, String descripcion, float costo, String duracion, String[] materiales, String[] intrumentos) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.costo = costo;
        this.duracion = duracion;
        this.materiales = materiales;
        this.intrumentos = intrumentos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public float getCosto() {
        return costo;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }

    public String getDuracion() {
        return duracion;
    }

    public void setDuracion(String duracion) {
        this.duracion = duracion;
    }

    public String[] getMateriales() {
        return materiales;
    }

    public void setMateriales(String[] materiales) {
        this.materiales = materiales;
    }

    public String[] getIntrumentos() {
        return intrumentos;
    }

    public void setIntrumentos(String[] intrumentos) {
        this.intrumentos = intrumentos;
    }
    
    public void agregarTratamiento(){
        
    }
}
