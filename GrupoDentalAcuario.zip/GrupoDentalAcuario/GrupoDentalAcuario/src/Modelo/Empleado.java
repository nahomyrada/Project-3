
package Modelo;


public class Empleado {
    private Horario horario;

    public Empleado() {
    }

    public Empleado(Horario horario) {
        this.horario = horario;
    }

    public Horario getHorario() {
        return horario;
    }

    public void setHorario(Horario horario) {
        this.horario = horario;
    }
    public void validarPerfil(String usuario, String contrasena){ //yo agregue contrasena
        
    }
    public void seleccionarEspecialistas(){
        
    }
    public void ingresarUsuario(){
        
    }
}
