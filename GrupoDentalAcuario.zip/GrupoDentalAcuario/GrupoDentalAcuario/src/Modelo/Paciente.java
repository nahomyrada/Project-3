
package Modelo;

import java.util.ArrayList;
import java.util.Date;


public class Paciente {
    private Tratamiento tratamientoRegistrado; //creo que esto no va
    private ArrayList<Cita> cita;
    private Pago pago;//ni esto xd
    private boolean tieneSeguro;
    private Seguro seguro;

    public Paciente() {
    }

    public Paciente(Tratamiento tratamientoRegistrado, ArrayList<Cita> cita, Pago pago, boolean tieneSeguro, Seguro seguro) {
        this.tratamientoRegistrado = tratamientoRegistrado;
        this.cita = cita;
        this.pago = pago;
        this.tieneSeguro = tieneSeguro;
        this.seguro = seguro;
    }

    public Tratamiento getTratamientoRegistrado() {
        return tratamientoRegistrado;
    }

    public void setTratamientoRegistrado(Tratamiento tratamientoRegistrado) {
        this.tratamientoRegistrado = tratamientoRegistrado;
    }

    public ArrayList<Cita> getCita() {
        return cita;
    }

    public void setCita(ArrayList<Cita> cita) {
        this.cita = cita;
    }

    public Pago getPago() {
        return pago;
    }

    public void setPago(Pago pago) {
        this.pago = pago;
    }

    public boolean isTieneSeguro() {
        return tieneSeguro;
    }

    public void setTieneSeguro(boolean tieneSeguro) {
        this.tieneSeguro = tieneSeguro;
    }

    public Seguro getSeguro() {
        return seguro;
    }

    public void setSeguro(Seguro seguro) {
        this.seguro = seguro;
    }
    
    public void indicarTratamientoRealizado(){
        
    }
    public void indicarFechaCita(){
        
    }
    public void verPacientes(){
        
    }
    public void buscarPaciente(String cedula){
        
    }
    public void marcarCitaCulminada(){
        
    }
    public void seleccionarCita(){
        
    }
    public void calcularCostoTratamiento(){
        
    }
    public void calcularDeducible(){
        
    }
    public void realizarPago(double monto){
        
    }
    public void compararPaciente(){
        
    }
    public void ingresarDatosPaciente(){
        
    }
    public void eliminarPaciente(){
        
    }
    public void obtenerLIstaPacientes(Date fechaInicial, Date fechaFinal){
        
    }
    public void calcularGananciaPorPaciente(){
        
    }
    public void mostratPaientes(){
        
    }
    public void mostrarInformacionPaciente(){
        
    }
}
