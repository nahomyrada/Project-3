
package Modelo;

import java.util.ArrayList;


public class GrupoDental {
    private float ganancias;
    private ArrayList<Empleado> empleados;

    public GrupoDental() {
    }

    public GrupoDental(float ganancias, ArrayList<Empleado> empleados) {
        this.ganancias = ganancias;
        this.empleados = empleados;
    }

    public float getGanancias() {
        return ganancias;
    }

    public void setGanancias(float ganancias) {
        this.ganancias = ganancias;
    }

    public ArrayList<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(ArrayList<Empleado> empleados) {
        this.empleados = empleados;
    }
    
    public void ingresarAPerfil(){
        
    }
    public void distribuirGanancias(){
        
    }
}
