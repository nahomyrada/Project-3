
package Modelo;


public class Administrador {
    private float salario;

    public Administrador() {
    }

    public Administrador(float salario) {
        this.salario = salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }
    public void gestionarCitas(){
        
    }
    public void gestionarHorarios(){
        
    }
    public void asignarSueldos(){
        
    }
    public void gestionarEspecialistas(){
        
    }
    public void verEspecialistas(){
        
    }
}
