
package Modelo;


public class Higienista {
    private Especialista especialistaAsistido;
    private float ganancias;

    public Higienista() {
    }

    public Higienista(Especialista especialistaAsistido, float ganancias) {
        this.especialistaAsistido = especialistaAsistido;
        this.ganancias = ganancias;
    }

    public Especialista getEspecialistaAsistido() {
        return especialistaAsistido;
    }

    public void setEspecialistaAsistido(Especialista especialistaAsistido) {
        this.especialistaAsistido = especialistaAsistido;
    }

    public float getGanancias() {
        return ganancias;
    }

    public void setGanancias(float ganancias) {
        this.ganancias = ganancias;
    }
    public void indicarCitasAsistidas() {
        
    }
    public void indicarEspecialistaAsistido() {
        
    }
}
