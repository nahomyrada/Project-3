package Modelo;

import java.util.ArrayList;
import java.util.Date;

public class Pago {
    private String tipoPago;
    private Date fechaPago;
    private float montoTotal;
    private Factura factura;
    private double dolarActual;
    private ArrayList<Pago> pagosRealizados;

    public Pago() {
    }

    public Pago(String tipoPago, Date fechaPago, float montoTotal, Factura factura, double dolarActual, ArrayList<Pago> pagosRealizados) {
        this.tipoPago = tipoPago;
        this.fechaPago = fechaPago;
        this.montoTotal = montoTotal;
        this.factura = factura;
        this.dolarActual = dolarActual;
        this.pagosRealizados = pagosRealizados;
    }

    
    public String getTipoPago() {
        return tipoPago;
    }

    public void setTipoPago(String tipoPago) {
        this.tipoPago = tipoPago;
    }

    public Date getFechaPago() {
        return fechaPago;
    }

    public void setFechaPago(Date fechaPago) {
        this.fechaPago = fechaPago;
    }

    public float getMontoTotal() {
        return montoTotal;
    }

    public void setMontoTotal(float montoTotal) {
        this.montoTotal = montoTotal;
    }

    public Factura getFactura() {
        return factura;
    }

    public void setFactura(Factura factura) {
        this.factura = factura;
    }

    public double getDolarActual() {
        return dolarActual;
    }

    public void setDolarActual(double dolarActual) {
        this.dolarActual = dolarActual;
    }

    public ArrayList<Pago> getPagosRealizados() {
        return pagosRealizados;
    }

    public void setPagosRealizados(ArrayList<Pago> pagosRealizados) {
        this.pagosRealizados = pagosRealizados;
    }
    
    public void realizarPago(){
        
    }
    public void elegirTipoPago(){
        
    }
    public float calcularPorcentajeTipoPago(){
        return 0;
    }
    public void indicarTratamientoRealizado(){
        
    }
    public void sumarPorcentajes(){
        
    }
    public float calcularPorcentajeGanancia(Date fechaInicial,Date fechaFinal){
        return 0;
    }
  
}
