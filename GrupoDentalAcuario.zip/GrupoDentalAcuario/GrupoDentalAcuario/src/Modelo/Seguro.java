
package Modelo;

import java.util.ArrayList;


public class Seguro {
    private int polizaSeguro;
    private String nombreCompania;
    private ArrayList<Tratamiento> informacionTratamientos; //no entiendo la existencia de esta lista
    private Pago deducible; //creo deberia ser tipo float

    public Seguro() {
    }

    public Seguro(int polizaSeguro, String nombreCompania, ArrayList<Tratamiento> informacionTratamientos, Pago deducible) {
        this.polizaSeguro = polizaSeguro;
        this.nombreCompania = nombreCompania;
        this.informacionTratamientos = informacionTratamientos;
        this.deducible = deducible;
    }

    
    public int getPolizaSeguro() {
        return polizaSeguro;
    }

    public void setPolizaSeguro(int polizaSeguro) {
        this.polizaSeguro = polizaSeguro;
    }

    public String getNombreCompania() {
        return nombreCompania;
    }

    public void setNombreCompania(String nombreCompania) {
        this.nombreCompania = nombreCompania;
    }

    public ArrayList<Tratamiento> getInformacionTratamientos() {
        return informacionTratamientos;
    }

    public void setInformacionTratamientos(ArrayList<Tratamiento> informacionTratamientos) {
        this.informacionTratamientos = informacionTratamientos;
    }

    public Pago getDeducible() {
        return deducible;
    }

    public void setDeducible(Pago deducible) {
        this.deducible = deducible;
    }
    public float calcularDeducible(){
        return 0;
    }
}
